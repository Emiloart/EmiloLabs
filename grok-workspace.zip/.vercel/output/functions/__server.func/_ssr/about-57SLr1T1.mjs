import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as SiteFrame, d as PageHero, h as PrincipleGrid, l as InstitutionMap, u as Origin } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-57SLr1T1.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			label: "ABOUT",
			title: "A technology institution built around connected problems.",
			summary: "Emilo Labs researches, designs, and builds systems for identity, privacy, security, intelligence, finance, communication, and digital coordination."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Origin, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstitutionMap, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrincipleGrid, {})
	] });
}
//#endregion
export { AboutPage as component };
