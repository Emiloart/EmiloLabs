import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as contactHref } from "./router-pkuxtI0L.mjs";
import { b as SiteFrame, d as PageHero, n as CareersGrid, t as AppLink, y as SectionLabel } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/careers-Dt4936Nx.js
var import_jsx_runtime = require_jsx_runtime();
function CareersPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			label: "CAREERS",
			title: "Build systems that deserve to exist.",
			summary: "A long-term talent network for engineering, research, security, design, and the work required to build the institution.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "page-hero-actions",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: contactHref("Talent inquiry"),
					className: "primary-button",
					children: "Introduce yourself"
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CareersGrid, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cta-band",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "OPEN APPLICATIONS" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Show the work, the judgment, and the systems you want to help build." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Send a concise introduction covering your strengths, relevant work, and the area you want to contribute to." })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
						href: contactHref("Talent inquiry"),
						className: "secondary-button",
						children: "Contact careers"
					})]
				})
			})
		})
	] });
}
//#endregion
export { CareersPage as component };
