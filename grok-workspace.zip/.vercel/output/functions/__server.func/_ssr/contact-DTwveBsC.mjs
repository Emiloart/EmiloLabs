import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as SiteFrame, d as PageHero, i as ContactPanel } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-DTwveBsC.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		label: "CONTACT",
		title: "Start a conversation with Emilo Labs.",
		summary: "For partnerships, research, product, media, careers, or general inquiries, contact the institution directly."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactPanel, {})] });
}
//#endregion
export { ContactPage as component };
