import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as SiteFrame, c as InsightGrid, d as PageHero } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-BJb66KeC.js
var import_jsx_runtime = require_jsx_runtime();
function InsightsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		label: "INSIGHTS",
		title: "One editorial hub for the institution's thinking and work.",
		summary: "Articles, research briefs, field notes, documentaries, announcements, and other published material share one coherent publishing surface."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightGrid, {})
		})
	})] });
}
//#endregion
export { InsightsPage as component };
