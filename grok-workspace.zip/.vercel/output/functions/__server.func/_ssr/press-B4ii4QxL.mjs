import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as SiteFrame, d as PageHero, m as PressResources } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/press-B4ii4QxL.js
var import_jsx_runtime = require_jsx_runtime();
function PressPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		label: "PRESS",
		title: "Official information for media and institutional inquiries.",
		summary: "A concise source for company context, media contact, and official information about Emilo Labs."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PressResources, {})] });
}
//#endregion
export { PressPage as component };
