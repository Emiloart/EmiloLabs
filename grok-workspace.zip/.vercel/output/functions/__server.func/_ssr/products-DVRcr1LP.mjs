import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Products, b as SiteFrame, d as PageHero, g as ProductOperatingModel } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products-DVRcr1LP.js
var import_jsx_runtime = require_jsx_runtime();
function ProductsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			label: "PRODUCTS",
			title: "Systems built for people, organizations, and connected digital environments.",
			summary: "The portfolio is presented in two states: Active and Coming Soon. That distinction keeps current products separate from systems still being prepared."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductOperatingModel, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Products, {})
	] });
}
//#endregion
export { ProductsPage as component };
