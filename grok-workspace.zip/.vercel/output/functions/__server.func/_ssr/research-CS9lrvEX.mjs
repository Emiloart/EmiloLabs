import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as SiteFrame, d as PageHero, p as PillarCards, v as ResearchTrackGrid } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/research-CS9lrvEX.js
var import_jsx_runtime = require_jsx_runtime();
function ResearchPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			label: "RESEARCH",
			title: "Questions worth solving before systems are scaled.",
			summary: "Research at Emilo Labs spans identity, privacy, security, intelligent systems, financial systems, and internet infrastructure."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResearchTrackGrid, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PillarCards, {})
	] });
}
//#endregion
export { ResearchPage as component };
