import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-pkuxtI0L.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var CONTACT_EMAIL = "emilolabs@gmail.com";
var NAV_LINKS = [
	{
		label: "About",
		href: "/about"
	},
	{
		label: "Research",
		href: "/research"
	},
	{
		label: "Technology",
		href: "/technology"
	},
	{
		label: "Products",
		href: "/products"
	},
	{
		label: "Insights",
		href: "/insights"
	},
	{
		label: "Careers",
		href: "/careers"
	},
	{
		label: "Press",
		href: "/press"
	}
];
var FOOTER_GROUPS = [
	{
		title: "Company",
		links: [
			{
				label: "About",
				href: "/about"
			},
			{
				label: "Press",
				href: "/press"
			},
			{
				label: "Contact",
				href: "/contact"
			}
		]
	},
	{
		title: "Work",
		links: [
			{
				label: "Research",
				href: "/research"
			},
			{
				label: "Technology",
				href: "/technology"
			},
			{
				label: "Products",
				href: "/products"
			}
		]
	},
	{
		title: "People",
		links: [{
			label: "Insights",
			href: "/insights"
		}, {
			label: "Careers",
			href: "/careers"
		}]
	}
];
var PAGE_META = {
	"/": {
		title: "Emilo Labs | Humanity first. Technology second.",
		description: "Emilo Labs is a technology institution building systems across identity, privacy, security, intelligence, finance, communication, and digital infrastructure."
	},
	"/about": {
		title: "About | Emilo Labs",
		description: "Understand the problems Emilo Labs exists to investigate and how research, infrastructure, products, and public impact connect."
	},
	"/research": {
		title: "Research | Emilo Labs",
		description: "Research domains and investigation tracks across identity, privacy, security, intelligent systems, finance, and internet infrastructure."
	},
	"/technology": {
		title: "Technology | Emilo Labs",
		description: "Engineering foundations spanning software systems, identity, privacy, security, intelligent systems, finance, data, and exploratory technology."
	},
	"/products": {
		title: "Products | Emilo Labs",
		description: "Active and upcoming Emilo Labs systems across communication, identity, verification, security, finance, and intelligent systems."
	},
	"/insights": {
		title: "Insights | Emilo Labs",
		description: "The Emilo Labs publishing hub for articles, research briefs, field notes, documentaries, and institutional updates."
	},
	"/careers": {
		title: "Careers | Emilo Labs",
		description: "The Emilo Labs talent network for engineering, research, security, design, and institutional work."
	},
	"/press": {
		title: "Press | Emilo Labs",
		description: "Official company context and media information for Emilo Labs."
	},
	"/contact": {
		title: "Contact | Emilo Labs",
		description: "Contact Emilo Labs for partnerships, research, products, careers, media, and general inquiries."
	}
};
var INSTITUTION_FLOW = [
	{
		title: "Research",
		text: "Defines the questions worth solving.",
		signal: "Direction",
		x: "50%",
		y: "14%"
	},
	{
		title: "Labs",
		text: "Tests ideas through experiments.",
		signal: "Exploration",
		x: "86%",
		y: "32%"
	},
	{
		title: "Infrastructure",
		text: "Builds reusable systems and protocols.",
		signal: "Foundation",
		x: "86%",
		y: "74%"
	},
	{
		title: "Products",
		text: "Delivers systems to people and organizations.",
		signal: "Surface",
		x: "14%",
		y: "74%"
	},
	{
		title: "Public Impact",
		text: "Improves safety, trust, and coordination online.",
		signal: "Outcome",
		x: "14%",
		y: "32%"
	}
];
var HOME_PATHS = [
	{
		href: "/research",
		signal: "Inquiry",
		title: "Research",
		text: "Identity, privacy, security, intelligence, finance, and internet systems."
	},
	{
		href: "/products",
		signal: "Surface",
		title: "Products",
		text: "Active systems for people and organizations, kept separate from upcoming work."
	},
	{
		href: "/technology",
		signal: "Foundation",
		title: "Technology",
		text: "The engineering stack behind credentials, defense, intelligence, and value."
	}
];
var RESEARCH_AREAS = [
	[
		"Identity",
		"Reusable proof and portable credentials.",
		"Trust"
	],
	[
		"Privacy",
		"Continuity and communication without unnecessary exposure.",
		"Privacy"
	],
	[
		"Security",
		"Threat-aware systems designed around failure and recovery.",
		"Defense"
	],
	[
		"Intelligent Systems",
		"Bounded AI assistance, structured reasoning, and automation.",
		"Intelligence"
	],
	[
		"Financial Systems",
		"Safer value exchange, lending, settlement, and coordination.",
		"Value"
	],
	[
		"Internet Systems",
		"Infrastructure for communication, coordination, and safer participation.",
		"Network"
	]
];
var RESEARCH_TRACKS = [
	[
		"Portable Identity and Proof",
		"How can people prove what matters without exposing more than necessary?",
		"Briefs, prototypes, credential models, recovery flows.",
		"Active investigation"
	],
	[
		"Privacy-Preserving Continuity",
		"How can access, communication, and recovery remain continuous when identity must stay protected?",
		"Private communication and anonymous continuity patterns.",
		"Active investigation"
	],
	[
		"Security Decision Systems",
		"How can digital environments detect risk earlier and support response before failure?",
		"Threat models, device trust, and ransomware defense research.",
		"Applied research"
	],
	[
		"Applied AI and Research Intelligence",
		"How can AI support research and operations without removing human accountability?",
		"Agent boundaries, structured research workflows, controlled automation.",
		"Applied research"
	],
	[
		"Health and Medical Technology Systems",
		"How can privacy and workflow safety improve health technology without overstating clinical claims?",
		"Workflow concepts, data safety research, assistive software patterns.",
		"Exploratory"
	],
	[
		"Industrial and Frontier Systems",
		"What infrastructure is needed for complex systems, automation, unfamiliar interfaces, and resilient coordination?",
		"Research notes, system maps, long-range prototypes.",
		"Exploratory"
	]
];
var PRODUCT_TIERS = [{
	title: "Active",
	products: [
		[
			"ShadeFast",
			"Social systems",
			"Anonymous communities for real world groups."
		],
		[
			"Reach",
			"Private communication",
			"Encrypted messaging and anonymous groups."
		],
		[
			"HDIP",
			"Identity",
			"Portable identity and credential infrastructure."
		],
		[
			"VerifyFlow",
			"Verification",
			"Controlled measurement for identity flows."
		],
		[
			"Achievo",
			"Credentials",
			"Verifiable achievement records."
		],
		[
			"LabGuard",
			"Security",
			"Device protection and recovery control."
		],
		[
			"LendEarn",
			"Finance",
			"Peer lending and referral finance."
		]
	]
}, {
	title: "Coming Soon",
	products: [
		[
			"ZKShade",
			"Privacy recovery",
			"Identity continuity without exposure."
		],
		[
			"ZKShade Starknet",
			"Identity recovery",
			"Anonymous recovery on Starknet."
		],
		[
			"UTB",
			"Research intelligence",
			"Automated research and structured insight."
		],
		[
			"HYEX",
			"Financial exchange",
			"Safer value exchange and settlement."
		],
		[
			"SCOS Pro",
			"Agent operations",
			"Autonomous coordination layer."
		],
		[
			"HSG Pro",
			"Safety intelligence",
			"Deception detection for digital environments."
		],
		[
			"SPFS Pro",
			"Personal finance",
			"AI native finance operating system."
		],
		[
			"ASL Pro",
			"Security automation",
			"Continuous vulnerability defense."
		],
		[
			"Ransomware DSS",
			"Threat defense",
			"Ransomware detection and deterrence."
		],
		[
			"AI Finance Tracker",
			"Finance intelligence",
			"Spending insight and budget intelligence."
		]
	]
}];
var TECHNOLOGY_AREAS = [
	[
		"Software & Internet Systems",
		"Applications, APIs, data services, and communication infrastructure.",
		"Systems layer"
	],
	[
		"Identity & Privacy",
		"Credentials, selective disclosure, anonymous continuity, and recovery.",
		"Trust layer"
	],
	[
		"Security Engineering",
		"Threat modeling, application security, and risk-aware system design.",
		"Defense layer"
	],
	[
		"Applied AI",
		"Research assistance, structured analysis, and bounded automation.",
		"Intelligence layer"
	],
	[
		"Financial Technology",
		"Lending workflows, value exchange, and settlement concepts.",
		"Value layer"
	],
	[
		"Infrastructure & Data",
		"Service architecture, data pipelines, and distributed components.",
		"Foundation layer"
	],
	[
		"Industrial Technology",
		"Exploratory work in automation, monitoring, and software-defined operations.",
		"Industry research"
	],
	[
		"Health Technology",
		"Exploration of privacy-aware data systems and safer digital workflows.",
		"Exploratory domain"
	],
	[
		"Frontier Systems",
		"Long-range inquiry into new interfaces and resilient system models.",
		"Frontier research"
	]
];
var ECOSYSTEM_MARKS = [
	["Starknet", "/ecosystem/starknet.svg"],
	["Aleo", "/ecosystem/aleo.svg"],
	["IOTA", "/ecosystem/iota.svg"],
	["Ethereum", "/ecosystem/ethereum.svg"],
	["Supabase", "/ecosystem/supabase.svg"],
	["WireGuard", "/ecosystem/wireguard.svg"],
	["Rust", "/ecosystem/rust.svg"],
	["Go", "/ecosystem/go.svg"],
	["React", "/ecosystem/react.svg"],
	["Three.js", "/ecosystem/threejs.svg"],
	["Vite", "/ecosystem/vite.svg"],
	["Node.js", "/ecosystem/nodejs.svg"],
	["PostgreSQL", "/ecosystem/postgresql.svg"],
	["Cloudflare", "/ecosystem/cloudflare.svg"],
	["Vercel", "/ecosystem/vercel.svg"]
];
var INSIGHTS = [
	[
		"Why digital trust needs institutional infrastructure",
		"Article",
		"Identity, privacy, verification, and security as connected infrastructure problems.",
		"Editorial pipeline",
		"7 min read",
		"Planned",
		true
	],
	[
		"Building products from research questions",
		"Blog Note",
		"How investigation areas become product surfaces without collapsing research into marketing.",
		"Editorial pipeline",
		"4 min read",
		"Planned",
		false
	],
	[
		"Identity continuity without unnecessary exposure",
		"Research Brief",
		"Portable proof, recovery, anonymous continuity, and connected product systems.",
		"Editorial pipeline",
		"6 min read",
		"Planned",
		true
	],
	[
		"The connected future: systems, safety, and coordination",
		"Documentary",
		"A future documentary track about infrastructure, internet safety, intelligent systems, and the institution.",
		"In development",
		"Watch series",
		"Future",
		false
	],
	[
		"Product ecosystem update",
		"Announcement",
		"A recurring format for active products, upcoming systems, partnerships, and institutional milestones.",
		"Editorial pipeline",
		"3 min read",
		"Template",
		false
	],
	[
		"Field notes from applied security work",
		"Field Report",
		"Operational lessons from security, device trust, vulnerability defense, and user-facing safety systems.",
		"Editorial pipeline",
		"5 min read",
		"Planned",
		false
	]
];
var CAREER_PATHS = [
	["Research collaborators", "Applied researchers, domain specialists, technical writers, and systems thinkers."],
	["Engineering talent", "Frontend, backend, security, AI, infrastructure, and product engineers."],
	["Design and product", "Interface designers, product strategists, experience researchers, and operators."],
	["Internships and early talent", "People who can learn quickly, document clearly, and help build serious systems."],
	["Institutional operations", "Partnerships, communications, finance, legal, and program coordination."]
];
var PRINCIPLES = [
	["Build for trust", "Digital systems should be safer, more verifiable, and more private by default."],
	["Research before scale", "Important technology should be shaped by clear questions, tests, and constraints."],
	["Products as surfaces", "Products are how deeper infrastructure reaches people, teams, and institutions."],
	["Avoid empty claims", "Ambition should be visible without presenting future research as finished proof."]
];
function contactHref(subject) {
	return `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(subject)}`;
}
var styles_default = "/assets/styles-CBDkj5Mr.css";
var Route$9 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: PAGE_META["/"].title },
			{
				name: "description",
				content: PAGE_META["/"].description
			},
			{
				name: "theme-color",
				content: "#06015e"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$8 = () => import("./routes-Cx3aRqVO.mjs");
var Route$8 = createFileRoute("/")({
	head: () => ({ meta: [{ title: PAGE_META["/"].title }, {
		name: "description",
		content: PAGE_META["/"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./about-57SLr1T1.mjs");
var Route$7 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: PAGE_META["/about"].title }, {
		name: "description",
		content: PAGE_META["/about"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./careers-Dt4936Nx.mjs");
var Route$6 = createFileRoute("/careers")({
	head: () => ({ meta: [{ title: PAGE_META["/careers"].title }, {
		name: "description",
		content: PAGE_META["/careers"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./contact-DTwveBsC.mjs");
var Route$5 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: PAGE_META["/contact"].title }, {
		name: "description",
		content: PAGE_META["/contact"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./insights-BJb66KeC.mjs");
var Route$4 = createFileRoute("/insights")({
	head: () => ({ meta: [{ title: PAGE_META["/insights"].title }, {
		name: "description",
		content: PAGE_META["/insights"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./press-B4ii4QxL.mjs");
var Route$3 = createFileRoute("/press")({
	head: () => ({ meta: [{ title: PAGE_META["/press"].title }, {
		name: "description",
		content: PAGE_META["/press"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./products-DVRcr1LP.mjs");
var Route$2 = createFileRoute("/products")({
	head: () => ({ meta: [{ title: PAGE_META["/products"].title }, {
		name: "description",
		content: PAGE_META["/products"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./research-CS9lrvEX.mjs");
var Route$1 = createFileRoute("/research")({
	head: () => ({ meta: [{ title: PAGE_META["/research"].title }, {
		name: "description",
		content: PAGE_META["/research"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./technology-DhEj74iU.mjs");
var Route = createFileRoute("/technology")({
	head: () => ({ meta: [{ title: PAGE_META["/technology"].title }, {
		name: "description",
		content: PAGE_META["/technology"].description
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$8.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$9
	}),
	AboutRoute: Route$7.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$9
	}),
	CareersRoute: Route$6.update({
		id: "/careers",
		path: "/careers",
		getParentRoute: () => Route$9
	}),
	ContactRoute: Route$5.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$9
	}),
	InsightsRoute: Route$4.update({
		id: "/insights",
		path: "/insights",
		getParentRoute: () => Route$9
	}),
	PressRoute: Route$3.update({
		id: "/press",
		path: "/press",
		getParentRoute: () => Route$9
	}),
	ProductsRoute: Route$2.update({
		id: "/products",
		path: "/products",
		getParentRoute: () => Route$9
	}),
	ResearchRoute: Route$1.update({
		id: "/research",
		path: "/research",
		getParentRoute: () => Route$9
	}),
	TechnologyRoute: Route.update({
		id: "/technology",
		path: "/technology",
		getParentRoute: () => Route$9
	})
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { FOOTER_GROUPS as a, INSTITUTION_FLOW as c, PRODUCT_TIERS as d, RESEARCH_AREAS as f, contactHref as h, ECOSYSTEM_MARKS as i, NAV_LINKS as l, TECHNOLOGY_AREAS as m, CAREER_PATHS as n, HOME_PATHS as o, RESEARCH_TRACKS as p, CONTACT_EMAIL as r, INSIGHTS as s, router_exports as t, PRINCIPLES as u };
