import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as SiteFrame, f as PathGrid, o as HomeHero, r as ContactBand, s as HomeProducts } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cx3aRqVO.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeHero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PathGrid, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeProducts, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactBand, {})
	] });
}
//#endregion
export { Home as component };
