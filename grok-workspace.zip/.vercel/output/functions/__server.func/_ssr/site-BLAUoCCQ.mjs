import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as FOOTER_GROUPS, c as INSTITUTION_FLOW, d as PRODUCT_TIERS, f as RESEARCH_AREAS, h as contactHref, i as ECOSYSTEM_MARKS, l as NAV_LINKS, m as TECHNOLOGY_AREAS, n as CAREER_PATHS, o as HOME_PATHS, p as RESEARCH_TRACKS, r as CONTACT_EMAIL, s as INSIGHTS, u as PRINCIPLES } from "./router-pkuxtI0L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-BLAUoCCQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppLink({ href, className = "", children, onClick }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	if (href.startsWith("mailto:") || href.startsWith("http")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		className,
		onClick,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: href,
		className: `${className} ${pathname === href ? "is-active" : ""}`.trim(),
		onClick,
		children
	});
}
function EmiloLogo({ compact = false, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		className,
		src: compact ? "/emilo-labs-mark.svg" : "/emilo-labs-logo.svg",
		alt: compact ? "" : "Emilo Labs",
		draggable: false
	});
}
function SectionLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "section-label",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children })
	});
}
function Navbar() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "nav",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nav-inner",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppLink, {
					href: "/",
					className: "brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmiloLogo, {
						compact: true,
						className: "brand-mark"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "EMILO LABS" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "desktop-nav",
					children: NAV_LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
						href: link.href,
						children: link.label
					}, link.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
					href: "/contact",
					className: "primary-button nav-cta",
					children: "Contact"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "menu-button",
					"aria-label": "Toggle navigation",
					"aria-expanded": open,
					onClick: () => setOpen((v) => !v),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `mobile-menu ${open ? "is-open" : ""}`,
			children: [NAV_LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
				href: link.href,
				children: link.label
			}, link.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
				href: "/contact",
				children: "Contact"
			})]
		})]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "footer",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container footer-inner",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppLink, {
					href: "/",
					className: "brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmiloLogo, {
						compact: true,
						className: "brand-mark"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "EMILO LABS" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "footer-groups",
					children: FOOTER_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "footer-group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: group.title }), group.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
							href: link.href,
							children: link.label
						}, link.href))]
					}, group.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Emilo Labs"
				] })
			]
		})
	});
}
function SiteFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site-shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function PageHero({ label, title, summary, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "page-hero",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container page-hero-inner",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: label }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: title }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: summary }),
				children
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hero-blend",
			"aria-hidden": "true"
		})]
	});
}
function InstitutionGraph() {
	const [active, setActive] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "institution-preview",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "panel-topline",
			children: "CONNECTED SYSTEM"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "institution-graph",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					className: "institution-links",
					viewBox: "0 0 100 100",
					"aria-hidden": "true",
					children: INSTITUTION_FLOW.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "50",
						y1: "50",
						x2: item.x.replace("%", ""),
						y2: item.y.replace("%", ""),
						className: active === index ? "is-active" : ""
					}, item.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "graph-core",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "core-ring" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmiloLogo, {
						compact: true,
						className: "preview-logo"
					})]
				}),
				INSTITUTION_FLOW.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `graph-node ${index === active ? "is-active" : ""}`,
					style: {
						"--x": item.x,
						"--y": item.y
					},
					onMouseEnter: () => setActive(index),
					onFocus: () => setActive(index),
					onClick: () => setActive(index),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.signal }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.text })
					]
				}, item.title))
			]
		})]
	});
}
function HomeHero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "hero-section",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container hero-grid",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hero-copy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hero-kicker",
						children: "EMILO LABS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Humanity first. Technology second." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Building connected systems with privacy, security, and human needs at the center." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
							href: "/about",
							className: "primary-button",
							children: "Explore the institution"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
							href: "/research",
							className: "secondary-button",
							children: "View research"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstitutionGraph, {})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hero-blend",
			"aria-hidden": "true"
		})]
	});
}
function PathGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "WORK" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "split-heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Three doors into the institution." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The homepage stays short. Research, products, and technology each have their own page." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "path-grid",
					children: HOME_PATHS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppLink, {
						href: item.href,
						className: "path-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.signal }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.title }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.text })
						]
					}, item.href))
				})
			]
		})
	});
}
function HomeProducts() {
	const active = PRODUCT_TIERS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "PRODUCTS" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "split-heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Active systems, named plainly." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						active.products.length,
						" live products. ",
						PRODUCT_TIERS[1].products.length,
						" still incoming. The split stays visible on the products page."
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "chip-row",
					children: active.products.map(([name]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "chip",
						children: name
					}, name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "home-actions",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLink, {
						href: "/products",
						className: "primary-button",
						children: "View product portfolio"
					})
				})
			]
		})
	});
}
function ContactBand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cta-band",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "CONTACT" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Work with Emilo Labs." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "For research, products, technology, or institutional communication." })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `mailto:${CONTACT_EMAIL}`,
					className: "primary-button",
					children: CONTACT_EMAIL
				})]
			})
		})
	});
}
function Origin() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container origin-layout",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "ORIGIN" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "origin-block",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Connected technology creates connected problems." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Identity needs verification. Communication needs privacy. Digital services need security. Online finance needs trust. Complex systems need coordination and recovery." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "These are infrastructure problems, not isolated product categories. Emilo Labs exists to research and build across that connective layer." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "origin-signal",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "EMILO LABS" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "At the Core of a Connected Future." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Research, infrastructure, products, and public impact connected by the systems people depend on." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "origin-close",
						children: "The institution works on the class of problems created by a connected digital world."
					})
				]
			})]
		})
	});
}
function InstitutionMap() {
	const [active, setActive] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "INSTITUTION" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relationship-map",
				children: INSTITUTION_FLOW.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `map-node ${index <= active ? "is-active" : ""}`,
					onMouseEnter: () => setActive(index),
					onFocus: () => setActive(index),
					onClick: () => setActive(index),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.signal }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.text })
					]
				}, item.title))
			})]
		})
	});
}
function PrincipleGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "OPERATING PRINCIPLES" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "initiative-grid",
				children: PRINCIPLES.map(([title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "initiative-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text })]
				}, title))
			})]
		})
	});
}
function ResearchTrackGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "RESEARCH TRACKS" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "track-grid",
				children: RESEARCH_TRACKS.map(([title, question, output, status]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "track-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: status }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: question }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: output })
					]
				}, title))
			})]
		})
	});
}
function PillarCards() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "RESEARCH DOMAINS" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "split-heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Six connected areas of investigation." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Each domain addresses a distinct systems problem while remaining connected to the wider layer." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pillar-grid",
					children: RESEARCH_AREAS.map(([title, description, signal]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "pillar-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: signal }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: description })
						]
					}, title))
				})
			]
		})
	});
}
function Products() {
	const [tierIndex, setTierIndex] = (0, import_react.useState)(0);
	const [productIndex, setProductIndex] = (0, import_react.useState)(0);
	const tier = PRODUCT_TIERS[tierIndex];
	const cards = (0, import_react.useMemo)(() => tier.products.map(([name, domain, summary]) => ({
		name,
		domain,
		summary
	})), [tier]);
	const active = tier.products[productIndex] ?? tier.products[0];
	const move = (offset) => setProductIndex((i) => (i + offset + cards.length) % cards.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "PORTFOLIO" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "tier-tabs",
					"aria-label": "Product status",
					children: PRODUCT_TIERS.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: index === tierIndex ? "is-active" : "",
						onClick: () => {
							setTierIndex(index);
							setProductIndex(0);
						},
						children: item.title
					}, item.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "product-stage",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "product-rail",
						children: cards.map((product, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `product-card ${index === productIndex ? "is-active" : ""}`,
							onClick: () => setProductIndex(index),
							"aria-pressed": index === productIndex,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: product.domain }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: product.name }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: product.summary })
							]
						}, product.name))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "active-product light-panel",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tier.title }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: active[0] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: active[2] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: active[1] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "product-controls",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => move(-1),
										"aria-label": "Previous product",
										children: "‹"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
										String(productIndex + 1).padStart(2, "0"),
										" / ",
										String(cards.length).padStart(2, "0")
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => move(1),
										"aria-label": "Next product",
										children: "›"
									})
								]
							})
						]
					})]
				})
			]
		})
	});
}
function ProductOperatingModel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "PORTFOLIO MODEL" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "split-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Products are the practical surface of deeper infrastructure." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Active systems are separated from upcoming systems so the portfolio communicates what exists now without presenting future work as finished." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chip-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "chip",
							children: "Active"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "chip",
							children: "Coming Soon"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "chip",
							children: "Research-backed"
						})
					]
				})]
			})]
		})
	});
}
function Technology() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "STACK" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "technology-grid",
				children: TECHNOLOGY_AREAS.map(([title, text, signal]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "technology-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: signal }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text })
					]
				}, title))
			})]
		})
	});
}
function CredibilityBand() {
	const loop = [...ECOSYSTEM_MARKS, ...ECOSYSTEM_MARKS];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "ECOSYSTEM" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ecosystem-marquee",
				"aria-label": "Technology ecosystem",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "ecosystem-track",
					children: loop.map(([name, logo], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ecosystem-logo",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: logo,
							alt: ""
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: name })]
					}, `${name}-${index}`))
				})
			})]
		})
	});
}
function InsightGrid({ featuredOnly = false }) {
	const items = featuredOnly ? INSIGHTS.filter((item) => item[6]) : INSIGHTS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "insight-grid",
		children: items.map(([title, category, summary, date, time, status]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "insight-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "insight-meta",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: category }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: status })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: summary }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "insight-foot",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: date }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: time })]
				})
			]
		}, title))
	});
}
function CareersGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "TALENT NETWORK" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "track-grid",
				children: CAREER_PATHS.map(([title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "track-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Open interest" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text })
					]
				}, title))
			})]
		})
	});
}
function PressResources() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "MEDIA READINESS" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "press-layout",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "press-boilerplate",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Official company context" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Emilo Labs is a technology institution and parent organization working across identity, privacy, security, intelligent systems, finance, communication, and digital infrastructure." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The organization connects research, infrastructure, products, and public impact around the problems created by increasingly connected digital systems." })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fact-list",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Organization" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Emilo Labs" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Technology institution" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Official contact" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: CONTACT_EMAIL })] })
					]
				})]
			})]
		})
	});
}
function ContactPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container contact-inner",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "contact-panel light-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "WRITE" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "contact-email",
					href: contactHref("Emilo Labs inquiry"),
					children: CONTACT_EMAIL
				})]
			})
		})
	});
}
//#endregion
export { Products as _, CredibilityBand as a, SiteFrame as b, InsightGrid as c, PageHero as d, PathGrid as f, ProductOperatingModel as g, PrincipleGrid as h, ContactPanel as i, InstitutionMap as l, PressResources as m, CareersGrid as n, HomeHero as o, PillarCards as p, ContactBand as r, HomeProducts as s, AppLink as t, Origin as u, ResearchTrackGrid as v, Technology as x, SectionLabel as y };
