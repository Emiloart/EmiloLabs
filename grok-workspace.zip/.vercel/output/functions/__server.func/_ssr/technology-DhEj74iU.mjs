import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as CredibilityBand, b as SiteFrame, d as PageHero, x as Technology } from "./site-BLAUoCCQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/technology-DhEj74iU.js
var import_jsx_runtime = require_jsx_runtime();
function TechnologyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			label: "TECHNOLOGY",
			title: "The engineering foundations behind the work.",
			summary: "Software systems, identity and privacy infrastructure, security engineering, intelligent systems, financial technology, and exploratory domains."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Technology, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CredibilityBand, {})
	] });
}
//#endregion
export { TechnologyPage as component };
