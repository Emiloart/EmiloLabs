//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D47rkDqO.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/careers",
			"/contact",
			"/insights",
			"/press",
			"/products",
			"/research",
			"/technology"
		],
		preloads: ["/assets/index-CgoDubvA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CgoDubvA.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DFm_8buT.js", "/assets/site-B2sYgQ5F.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-Bp3ny8KV.js", "/assets/site-B2sYgQ5F.js"]
	},
	"/careers": {
		filePath: "/workspace/src/routes/careers.tsx",
		children: void 0,
		preloads: ["/assets/careers-C3ve7KlZ.js", "/assets/site-B2sYgQ5F.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-H66svqdI.js", "/assets/site-B2sYgQ5F.js"]
	},
	"/insights": {
		filePath: "/workspace/src/routes/insights.tsx",
		children: void 0,
		preloads: ["/assets/insights-BkTN-FiX.js", "/assets/site-B2sYgQ5F.js"]
	},
	"/press": {
		filePath: "/workspace/src/routes/press.tsx",
		children: void 0,
		preloads: ["/assets/press-BCSdpD7O.js", "/assets/site-B2sYgQ5F.js"]
	},
	"/products": {
		filePath: "/workspace/src/routes/products.tsx",
		children: void 0,
		preloads: ["/assets/products-DQSk87hN.js", "/assets/site-B2sYgQ5F.js"]
	},
	"/research": {
		filePath: "/workspace/src/routes/research.tsx",
		children: void 0,
		preloads: ["/assets/research-CLOpFkE-.js", "/assets/site-B2sYgQ5F.js"]
	},
	"/technology": {
		filePath: "/workspace/src/routes/technology.tsx",
		children: void 0,
		preloads: ["/assets/technology-CaT8dz-O.js", "/assets/site-B2sYgQ5F.js"]
	}
} });
//#endregion
export { tsrStartManifest };
