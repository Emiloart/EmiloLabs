import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type CSSProperties, type ReactNode } from "react";
import {
  CAREER_PATHS,
  CONTACT_EMAIL,
  ECOSYSTEM_MARKS,
  HOME_PATHS,
  INSIGHTS,
  INSTITUTION_FLOW,
  NAV_LINKS,
  FOOTER_GROUPS,
  PRINCIPLES,
  PRODUCT_TIERS,
  RESEARCH_AREAS,
  RESEARCH_TRACKS,
  TECHNOLOGY_AREAS,
  contactHref,
} from "@/lib/content";

type AppLinkProps = {
  href: string;
  className?: string;
  children: ReactNode;
  onClick?: () => void;
};

export function AppLink({ href, className = "", children, onClick }: AppLinkProps) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (href.startsWith("mailto:") || href.startsWith("http")) {
    return (
      <a href={href} className={className} onClick={onClick}>
        {children}
      </a>
    );
  }
  const active = pathname === href;
  return (
    <Link to={href as "/"} className={`${className} ${active ? "is-active" : ""}`.trim()} onClick={onClick}>
      {children}
    </Link>
  );
}

export function EmiloLogo({ compact = false, className = "" }: { compact?: boolean; className?: string }) {
  return (
    <img
      className={className}
      src={compact ? "/emilo-labs-mark.svg" : "/emilo-labs-logo.svg"}
      alt={compact ? "" : "Emilo Labs"}
      draggable={false}
    />
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div className="section-label">
      <strong>{children}</strong>
    </div>
  );
}

export function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <nav className="nav">
      <div className="nav-inner">
        <AppLink href="/" className="brand">
          <EmiloLogo compact className="brand-mark" />
          <span>EMILO LABS</span>
        </AppLink>
        <div className="desktop-nav">
          {NAV_LINKS.map((link) => (
            <AppLink key={link.href} href={link.href}>
              {link.label}
            </AppLink>
          ))}
        </div>
        <AppLink href="/contact" className="primary-button nav-cta">
          Contact
        </AppLink>
        <button
          type="button"
          className="menu-button"
          aria-label="Toggle navigation"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
      <div className={`mobile-menu ${open ? "is-open" : ""}`}>
        {NAV_LINKS.map((link) => (
          <AppLink key={link.href} href={link.href}>
            {link.label}
          </AppLink>
        ))}
        <AppLink href="/contact">Contact</AppLink>
      </div>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <AppLink href="/" className="brand">
          <EmiloLogo compact className="brand-mark" />
          <span>EMILO LABS</span>
        </AppLink>
        <div className="footer-groups">
          {FOOTER_GROUPS.map((group) => (
            <div key={group.title} className="footer-group">
              <strong>{group.title}</strong>
              {group.links.map((link) => (
                <AppLink key={link.href} href={link.href}>
                  {link.label}
                </AppLink>
              ))}
            </div>
          ))}
        </div>
        <small>© {new Date().getFullYear()} Emilo Labs</small>
      </div>
    </footer>
  );
}

export function SiteFrame({ children }: { children: ReactNode }) {
  return (
    <div className="site-shell">
      <Navbar />
      <main>{children}</main>
      <Footer />
    </div>
  );
}

export function PageHero({
  label,
  title,
  summary,
  children,
}: {
  label: string;
  title: string;
  summary: string;
  children?: ReactNode;
}) {
  return (
    <header className="page-hero">
      <div className="container page-hero-inner">
        <SectionLabel>{label}</SectionLabel>
        <h1>{title}</h1>
        <p>{summary}</p>
        {children}
      </div>
      <div className="hero-blend" aria-hidden="true" />
    </header>
  );
}

export function InstitutionGraph() {
  const [active, setActive] = useState(0);

  return (
    <div className="institution-preview">
      <div className="panel-topline">CONNECTED SYSTEM</div>
      <div className="institution-graph">
        <svg className="institution-links" viewBox="0 0 100 100" aria-hidden="true">
          {INSTITUTION_FLOW.map((item, index) => (
            <line
              key={item.title}
              x1="50"
              y1="50"
              x2={item.x.replace("%", "")}
              y2={item.y.replace("%", "")}
              className={active === index ? "is-active" : ""}
            />
          ))}
        </svg>
        <div className="graph-core">
          <div className="core-ring" />
          <EmiloLogo compact className="preview-logo" />
        </div>
        {INSTITUTION_FLOW.map((item, index) => (
          <button
            key={item.title}
            type="button"
            className={`graph-node ${index === active ? "is-active" : ""}`}
            style={{ "--x": item.x, "--y": item.y } as CSSProperties}
            onMouseEnter={() => setActive(index)}
            onFocus={() => setActive(index)}
            onClick={() => setActive(index)}
          >
            <span>{item.signal}</span>
            <strong>{item.title}</strong>
            <p>{item.text}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

export function HomeHero() {
  return (
    <header className="hero-section">
      <div className="container hero-grid">
        <div className="hero-copy">
          <div className="hero-kicker">EMILO LABS</div>
          <h1>Humanity first. Technology second.</h1>
          <p>Building connected systems with privacy, security, and human needs at the center.</p>
          <div className="hero-actions">
            <AppLink href="/about" className="primary-button">
              Explore the institution
            </AppLink>
            <AppLink href="/research" className="secondary-button">
              View research
            </AppLink>
          </div>
        </div>
        <InstitutionGraph />
      </div>
      <div className="hero-blend" aria-hidden="true" />
    </header>
  );
}

export function PathGrid() {
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>WORK</SectionLabel>
        <div className="split-heading">
          <h2>Three doors into the institution.</h2>
          <p>The homepage stays short. Research, products, and technology each have their own page.</p>
        </div>
        <div className="path-grid">
          {HOME_PATHS.map((item) => (
            <AppLink key={item.href} href={item.href} className="path-card">
              <span>{item.signal}</span>
              <strong>{item.title}</strong>
              <p>{item.text}</p>
            </AppLink>
          ))}
        </div>
      </div>
    </section>
  );
}

export function HomeProducts() {
  const active = PRODUCT_TIERS[0];
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>PRODUCTS</SectionLabel>
        <div className="split-heading">
          <h2>Active systems, named plainly.</h2>
          <p>
            {active.products.length} live products. {PRODUCT_TIERS[1].products.length} still incoming. The
            split stays visible on the products page.
          </p>
        </div>
        <div className="chip-row">
          {active.products.map(([name]) => (
            <span key={name} className="chip">
              {name}
            </span>
          ))}
        </div>
        <div className="home-actions">
          <AppLink href="/products" className="primary-button">
            View product portfolio
          </AppLink>
        </div>
      </div>
    </section>
  );
}

export function ContactBand() {
  return (
    <section className="section">
      <div className="container">
        <div className="cta-band">
          <div>
            <SectionLabel>CONTACT</SectionLabel>
            <h2>Work with Emilo Labs.</h2>
            <p>For research, products, technology, or institutional communication.</p>
          </div>
          <a href={`mailto:${CONTACT_EMAIL}`} className="primary-button">
            {CONTACT_EMAIL}
          </a>
        </div>
      </div>
    </section>
  );
}

export function Origin() {
  return (
    <section className="section">
      <div className="container origin-layout">
        <SectionLabel>ORIGIN</SectionLabel>
        <div className="origin-block">
          <p>Connected technology creates connected problems.</p>
          <p>
            Identity needs verification. Communication needs privacy. Digital services need security. Online
            finance needs trust. Complex systems need coordination and recovery.
          </p>
          <p>
            These are infrastructure problems, not isolated product categories. Emilo Labs exists to research
            and build across that connective layer.
          </p>
          <div className="origin-signal">
            <span>EMILO LABS</span>
            <strong>At the Core of a Connected Future.</strong>
            <p>Research, infrastructure, products, and public impact connected by the systems people depend on.</p>
          </div>
          <p className="origin-close">The institution works on the class of problems created by a connected digital world.</p>
        </div>
      </div>
    </section>
  );
}

export function InstitutionMap() {
  const [active, setActive] = useState(0);
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>INSTITUTION</SectionLabel>
        <div className="relationship-map">
          {INSTITUTION_FLOW.map((item, index) => (
            <button
              key={item.title}
              type="button"
              className={`map-node ${index <= active ? "is-active" : ""}`}
              onMouseEnter={() => setActive(index)}
              onFocus={() => setActive(index)}
              onClick={() => setActive(index)}
            >
              <span>{item.signal}</span>
              <strong>{item.title}</strong>
              <p>{item.text}</p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

export function PrincipleGrid() {
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>OPERATING PRINCIPLES</SectionLabel>
        <div className="initiative-grid">
          {PRINCIPLES.map(([title, text]) => (
            <article key={title} className="initiative-card">
              <strong>{title}</strong>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ResearchTrackGrid() {
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>RESEARCH TRACKS</SectionLabel>
        <div className="track-grid">
          {RESEARCH_TRACKS.map(([title, question, output, status]) => (
            <article key={title} className="track-card">
              <span>{status}</span>
              <strong>{title}</strong>
              <p>{question}</p>
              <small>{output}</small>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function PillarCards() {
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>RESEARCH DOMAINS</SectionLabel>
        <div className="split-heading">
          <h2>Six connected areas of investigation.</h2>
          <p>Each domain addresses a distinct systems problem while remaining connected to the wider layer.</p>
        </div>
        <div className="pillar-grid">
          {RESEARCH_AREAS.map(([title, description, signal]) => (
            <article key={title} className="pillar-card">
              <span>{signal}</span>
              <strong>{title}</strong>
              <p>{description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Products() {
  const [tierIndex, setTierIndex] = useState(0);
  const [productIndex, setProductIndex] = useState(0);
  const tier = PRODUCT_TIERS[tierIndex];
  const cards = useMemo(
    () => tier.products.map(([name, domain, summary]) => ({ name, domain, summary })),
    [tier],
  );
  const active = tier.products[productIndex] ?? tier.products[0];
  const move = (offset: number) => setProductIndex((i) => (i + offset + cards.length) % cards.length);

  return (
    <section className="section">
      <div className="container">
        <SectionLabel>PORTFOLIO</SectionLabel>
        <div className="tier-tabs" aria-label="Product status">
          {PRODUCT_TIERS.map((item, index) => (
            <button
              key={item.title}
              type="button"
              className={index === tierIndex ? "is-active" : ""}
              onClick={() => {
                setTierIndex(index);
                setProductIndex(0);
              }}
            >
              {item.title}
            </button>
          ))}
        </div>
        <div className="product-stage">
          <div className="product-rail">
            {cards.map((product, index) => (
              <button
                key={product.name}
                type="button"
                className={`product-card ${index === productIndex ? "is-active" : ""}`}
                onClick={() => setProductIndex(index)}
                aria-pressed={index === productIndex}
              >
                <span>{product.domain}</span>
                <strong>{product.name}</strong>
                <p>{product.summary}</p>
              </button>
            ))}
          </div>
          <aside className="active-product light-panel">
            <span>{tier.title}</span>
            <h3>{active[0]}</h3>
            <p>{active[2]}</p>
            <strong>{active[1]}</strong>
            <div className="product-controls">
              <button type="button" onClick={() => move(-1)} aria-label="Previous product">
                ‹
              </button>
              <small>
                {String(productIndex + 1).padStart(2, "0")} / {String(cards.length).padStart(2, "0")}
              </small>
              <button type="button" onClick={() => move(1)} aria-label="Next product">
                ›
              </button>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

export function ProductOperatingModel() {
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>PORTFOLIO MODEL</SectionLabel>
        <div className="split-panel">
          <div>
            <h2>Products are the practical surface of deeper infrastructure.</h2>
            <p>
              Active systems are separated from upcoming systems so the portfolio communicates what exists now
              without presenting future work as finished.
            </p>
          </div>
          <div className="chip-row">
            <span className="chip">Active</span>
            <span className="chip">Coming Soon</span>
            <span className="chip">Research-backed</span>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Technology() {
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>STACK</SectionLabel>
        <div className="technology-grid">
          {TECHNOLOGY_AREAS.map(([title, text, signal]) => (
            <article key={title} className="technology-card">
              <span>{signal}</span>
              <strong>{title}</strong>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function CredibilityBand() {
  const loop = [...ECOSYSTEM_MARKS, ...ECOSYSTEM_MARKS];
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>ECOSYSTEM</SectionLabel>
        <div className="ecosystem-marquee" aria-label="Technology ecosystem">
          <div className="ecosystem-track">
            {loop.map(([name, logo], index) => (
              <div className="ecosystem-logo" key={`${name}-${index}`}>
                <span>
                  <img src={logo} alt="" />
                </span>
                <strong>{name}</strong>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function InsightGrid({ featuredOnly = false }: { featuredOnly?: boolean }) {
  const items = featuredOnly ? INSIGHTS.filter((item) => item[6]) : INSIGHTS;
  return (
    <div className="insight-grid">
      {items.map(([title, category, summary, date, time, status]) => (
        <article key={title} className="insight-card">
          <div className="insight-meta">
            <span>{category}</span>
            <small>{status}</small>
          </div>
          <strong>{title}</strong>
          <p>{summary}</p>
          <div className="insight-foot">
            <span>{date}</span>
            <span>{time}</span>
          </div>
        </article>
      ))}
    </div>
  );
}

export function CareersGrid() {
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>TALENT NETWORK</SectionLabel>
        <div className="track-grid">
          {CAREER_PATHS.map(([title, text]) => (
            <article key={title} className="track-card">
              <span>Open interest</span>
              <strong>{title}</strong>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function PressResources() {
  return (
    <section className="section">
      <div className="container">
        <SectionLabel>MEDIA READINESS</SectionLabel>
        <div className="press-layout">
          <article className="press-boilerplate">
            <h2>Official company context</h2>
            <p>
              Emilo Labs is a technology institution and parent organization working across identity, privacy,
              security, intelligent systems, finance, communication, and digital infrastructure.
            </p>
            <p>
              The organization connects research, infrastructure, products, and public impact around the
              problems created by increasingly connected digital systems.
            </p>
          </article>
          <div className="fact-list">
            <div>
              <span>Organization</span>
              <strong>Emilo Labs</strong>
            </div>
            <div>
              <span>Type</span>
              <strong>Technology institution</strong>
            </div>
            <div>
              <span>Official contact</span>
              <strong>{CONTACT_EMAIL}</strong>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function ContactPanel() {
  return (
    <section className="section">
      <div className="container contact-inner">
        <div className="contact-panel light-panel">
          <SectionLabel>WRITE</SectionLabel>
          <a className="contact-email" href={contactHref("Emilo Labs inquiry")}>
            {CONTACT_EMAIL}
          </a>
        </div>
      </div>
    </section>
  );
}
