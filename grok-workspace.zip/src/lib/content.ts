export const CONTACT_EMAIL = "emilolabs@gmail.com";

export const NAV_LINKS = [
  { label: "About", href: "/about" },
  { label: "Research", href: "/research" },
  { label: "Technology", href: "/technology" },
  { label: "Products", href: "/products" },
  { label: "Insights", href: "/insights" },
  { label: "Careers", href: "/careers" },
  { label: "Press", href: "/press" },
] as const;

export const FOOTER_GROUPS = [
  {
    title: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Press", href: "/press" },
      { label: "Contact", href: "/contact" },
    ],
  },
  {
    title: "Work",
    links: [
      { label: "Research", href: "/research" },
      { label: "Technology", href: "/technology" },
      { label: "Products", href: "/products" },
    ],
  },
  {
    title: "People",
    links: [
      { label: "Insights", href: "/insights" },
      { label: "Careers", href: "/careers" },
    ],
  },
] as const;

export const PAGE_META: Record<string, { title: string; description: string }> = {
  "/": {
    title: "Emilo Labs | Humanity first. Technology second.",
    description:
      "Emilo Labs is a technology institution building systems across identity, privacy, security, intelligence, finance, communication, and digital infrastructure.",
  },
  "/about": {
    title: "About | Emilo Labs",
    description:
      "Understand the problems Emilo Labs exists to investigate and how research, infrastructure, products, and public impact connect.",
  },
  "/research": {
    title: "Research | Emilo Labs",
    description:
      "Research domains and investigation tracks across identity, privacy, security, intelligent systems, finance, and internet infrastructure.",
  },
  "/technology": {
    title: "Technology | Emilo Labs",
    description:
      "Engineering foundations spanning software systems, identity, privacy, security, intelligent systems, finance, data, and exploratory technology.",
  },
  "/products": {
    title: "Products | Emilo Labs",
    description:
      "Active and upcoming Emilo Labs systems across communication, identity, verification, security, finance, and intelligent systems.",
  },
  "/insights": {
    title: "Insights | Emilo Labs",
    description:
      "The Emilo Labs publishing hub for articles, research briefs, field notes, documentaries, and institutional updates.",
  },
  "/careers": {
    title: "Careers | Emilo Labs",
    description: "The Emilo Labs talent network for engineering, research, security, design, and institutional work.",
  },
  "/press": {
    title: "Press | Emilo Labs",
    description: "Official company context and media information for Emilo Labs.",
  },
  "/contact": {
    title: "Contact | Emilo Labs",
    description:
      "Contact Emilo Labs for partnerships, research, products, careers, media, and general inquiries.",
  },
};

export const INSTITUTION_FLOW = [
  { title: "Research", text: "Defines the questions worth solving.", signal: "Direction", x: "50%", y: "14%" },
  { title: "Labs", text: "Tests ideas through experiments.", signal: "Exploration", x: "86%", y: "32%" },
  { title: "Infrastructure", text: "Builds reusable systems and protocols.", signal: "Foundation", x: "86%", y: "74%" },
  { title: "Products", text: "Delivers systems to people and organizations.", signal: "Surface", x: "14%", y: "74%" },
  { title: "Public Impact", text: "Improves safety, trust, and coordination online.", signal: "Outcome", x: "14%", y: "32%" },
] as const;

export const HOME_PATHS = [
  {
    href: "/research",
    signal: "Inquiry",
    title: "Research",
    text: "Identity, privacy, security, intelligence, finance, and internet systems.",
  },
  {
    href: "/products",
    signal: "Surface",
    title: "Products",
    text: "Active systems for people and organizations, kept separate from upcoming work.",
  },
  {
    href: "/technology",
    signal: "Foundation",
    title: "Technology",
    text: "The engineering stack behind credentials, defense, intelligence, and value.",
  },
] as const;

export const RESEARCH_AREAS = [
  ["Identity", "Reusable proof and portable credentials.", "Trust"],
  ["Privacy", "Continuity and communication without unnecessary exposure.", "Privacy"],
  ["Security", "Threat-aware systems designed around failure and recovery.", "Defense"],
  ["Intelligent Systems", "Bounded AI assistance, structured reasoning, and automation.", "Intelligence"],
  ["Financial Systems", "Safer value exchange, lending, settlement, and coordination.", "Value"],
  ["Internet Systems", "Infrastructure for communication, coordination, and safer participation.", "Network"],
] as const;

export const RESEARCH_TRACKS = [
  [
    "Portable Identity and Proof",
    "How can people prove what matters without exposing more than necessary?",
    "Briefs, prototypes, credential models, recovery flows.",
    "Active investigation",
  ],
  [
    "Privacy-Preserving Continuity",
    "How can access, communication, and recovery remain continuous when identity must stay protected?",
    "Private communication and anonymous continuity patterns.",
    "Active investigation",
  ],
  [
    "Security Decision Systems",
    "How can digital environments detect risk earlier and support response before failure?",
    "Threat models, device trust, and ransomware defense research.",
    "Applied research",
  ],
  [
    "Applied AI and Research Intelligence",
    "How can AI support research and operations without removing human accountability?",
    "Agent boundaries, structured research workflows, controlled automation.",
    "Applied research",
  ],
  [
    "Health and Medical Technology Systems",
    "How can privacy and workflow safety improve health technology without overstating clinical claims?",
    "Workflow concepts, data safety research, assistive software patterns.",
    "Exploratory",
  ],
  [
    "Industrial and Frontier Systems",
    "What infrastructure is needed for complex systems, automation, unfamiliar interfaces, and resilient coordination?",
    "Research notes, system maps, long-range prototypes.",
    "Exploratory",
  ],
] as const;

export const PRODUCT_TIERS = [
  {
    title: "Active",
    products: [
      ["ShadeFast", "Social systems", "Anonymous communities for real world groups."],
      ["Reach", "Private communication", "Encrypted messaging and anonymous groups."],
      ["HDIP", "Identity", "Portable identity and credential infrastructure."],
      ["VerifyFlow", "Verification", "Controlled measurement for identity flows."],
      ["Achievo", "Credentials", "Verifiable achievement records."],
      ["LabGuard", "Security", "Device protection and recovery control."],
      ["LendEarn", "Finance", "Peer lending and referral finance."],
    ],
  },
  {
    title: "Coming Soon",
    products: [
      ["ZKShade", "Privacy recovery", "Identity continuity without exposure."],
      ["ZKShade Starknet", "Identity recovery", "Anonymous recovery on Starknet."],
      ["UTB", "Research intelligence", "Automated research and structured insight."],
      ["HYEX", "Financial exchange", "Safer value exchange and settlement."],
      ["SCOS Pro", "Agent operations", "Autonomous coordination layer."],
      ["HSG Pro", "Safety intelligence", "Deception detection for digital environments."],
      ["SPFS Pro", "Personal finance", "AI native finance operating system."],
      ["ASL Pro", "Security automation", "Continuous vulnerability defense."],
      ["Ransomware DSS", "Threat defense", "Ransomware detection and deterrence."],
      ["AI Finance Tracker", "Finance intelligence", "Spending insight and budget intelligence."],
    ],
  },
] as const;

export const TECHNOLOGY_AREAS = [
  ["Software & Internet Systems", "Applications, APIs, data services, and communication infrastructure.", "Systems layer"],
  ["Identity & Privacy", "Credentials, selective disclosure, anonymous continuity, and recovery.", "Trust layer"],
  ["Security Engineering", "Threat modeling, application security, and risk-aware system design.", "Defense layer"],
  ["Applied AI", "Research assistance, structured analysis, and bounded automation.", "Intelligence layer"],
  ["Financial Technology", "Lending workflows, value exchange, and settlement concepts.", "Value layer"],
  ["Infrastructure & Data", "Service architecture, data pipelines, and distributed components.", "Foundation layer"],
  ["Industrial Technology", "Exploratory work in automation, monitoring, and software-defined operations.", "Industry research"],
  ["Health Technology", "Exploration of privacy-aware data systems and safer digital workflows.", "Exploratory domain"],
  ["Frontier Systems", "Long-range inquiry into new interfaces and resilient system models.", "Frontier research"],
] as const;

export const ECOSYSTEM_MARKS = [
  ["Starknet", "/ecosystem/starknet.svg"],
  ["Aleo", "/ecosystem/aleo.svg"],
  ["IOTA", "/ecosystem/iota.svg"],
  ["Ethereum", "/ecosystem/ethereum.svg"],
  ["Supabase", "/ecosystem/supabase.svg"],
  ["WireGuard", "/ecosystem/wireguard.svg"],
  ["Rust", "/ecosystem/rust.svg"],
  ["Go", "/ecosystem/go.svg"],
  ["React", "/ecosystem/react.svg"],
  ["Three.js", "/ecosystem/threejs.svg"],
  ["Vite", "/ecosystem/vite.svg"],
  ["Node.js", "/ecosystem/nodejs.svg"],
  ["PostgreSQL", "/ecosystem/postgresql.svg"],
  ["Cloudflare", "/ecosystem/cloudflare.svg"],
  ["Vercel", "/ecosystem/vercel.svg"],
] as const;

export const INSIGHTS = [
  [
    "Why digital trust needs institutional infrastructure",
    "Article",
    "Identity, privacy, verification, and security as connected infrastructure problems.",
    "Editorial pipeline",
    "7 min read",
    "Planned",
    true,
  ],
  [
    "Building products from research questions",
    "Blog Note",
    "How investigation areas become product surfaces without collapsing research into marketing.",
    "Editorial pipeline",
    "4 min read",
    "Planned",
    false,
  ],
  [
    "Identity continuity without unnecessary exposure",
    "Research Brief",
    "Portable proof, recovery, anonymous continuity, and connected product systems.",
    "Editorial pipeline",
    "6 min read",
    "Planned",
    true,
  ],
  [
    "The connected future: systems, safety, and coordination",
    "Documentary",
    "A future documentary track about infrastructure, internet safety, intelligent systems, and the institution.",
    "In development",
    "Watch series",
    "Future",
    false,
  ],
  [
    "Product ecosystem update",
    "Announcement",
    "A recurring format for active products, upcoming systems, partnerships, and institutional milestones.",
    "Editorial pipeline",
    "3 min read",
    "Template",
    false,
  ],
  [
    "Field notes from applied security work",
    "Field Report",
    "Operational lessons from security, device trust, vulnerability defense, and user-facing safety systems.",
    "Editorial pipeline",
    "5 min read",
    "Planned",
    false,
  ],
] as const;

export const CAREER_PATHS = [
  ["Research collaborators", "Applied researchers, domain specialists, technical writers, and systems thinkers."],
  ["Engineering talent", "Frontend, backend, security, AI, infrastructure, and product engineers."],
  ["Design and product", "Interface designers, product strategists, experience researchers, and operators."],
  ["Internships and early talent", "People who can learn quickly, document clearly, and help build serious systems."],
  ["Institutional operations", "Partnerships, communications, finance, legal, and program coordination."],
] as const;

export const PRINCIPLES = [
  ["Build for trust", "Digital systems should be safer, more verifiable, and more private by default."],
  ["Research before scale", "Important technology should be shaped by clear questions, tests, and constraints."],
  ["Products as surfaces", "Products are how deeper infrastructure reaches people, teams, and institutions."],
  ["Avoid empty claims", "Ambition should be visible without presenting future research as finished proof."],
] as const;

export function contactHref(subject: string) {
  return `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(subject)}`;
}
