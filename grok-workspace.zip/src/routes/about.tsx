import { createFileRoute } from "@tanstack/react-router";
import { InstitutionMap, Origin, PageHero, PrincipleGrid, SiteFrame } from "@/components/site";
import { PAGE_META } from "@/lib/content";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: PAGE_META["/about"].title },
      { name: "description", content: PAGE_META["/about"].description },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteFrame>
      <PageHero
        label="ABOUT"
        title="A technology institution built around connected problems."
        summary="Emilo Labs researches, designs, and builds systems for identity, privacy, security, intelligence, finance, communication, and digital coordination."
      />
      <Origin />
      <InstitutionMap />
      <PrincipleGrid />
    </SiteFrame>
  );
}
