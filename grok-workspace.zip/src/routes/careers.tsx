import { createFileRoute } from "@tanstack/react-router";
import { AppLink, CareersGrid, PageHero, SectionLabel, SiteFrame } from "@/components/site";
import { PAGE_META, contactHref } from "@/lib/content";

export const Route = createFileRoute("/careers")({
  head: () => ({
    meta: [
      { title: PAGE_META["/careers"].title },
      { name: "description", content: PAGE_META["/careers"].description },
    ],
  }),
  component: CareersPage,
});

function CareersPage() {
  return (
    <SiteFrame>
      <PageHero
        label="CAREERS"
        title="Build systems that deserve to exist."
        summary="A long-term talent network for engineering, research, security, design, and the work required to build the institution."
      >
        <div className="page-hero-actions">
          <a href={contactHref("Talent inquiry")} className="primary-button">
            Introduce yourself
          </a>
        </div>
      </PageHero>
      <CareersGrid />
      <section className="section">
        <div className="container">
          <div className="cta-band">
            <div>
              <SectionLabel>OPEN APPLICATIONS</SectionLabel>
              <h2>Show the work, the judgment, and the systems you want to help build.</h2>
              <p>Send a concise introduction covering your strengths, relevant work, and the area you want to contribute to.</p>
            </div>
            <AppLink href={contactHref("Talent inquiry")} className="secondary-button">
              Contact careers
            </AppLink>
          </div>
        </div>
      </section>
    </SiteFrame>
  );
}
