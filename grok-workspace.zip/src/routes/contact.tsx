import { createFileRoute } from "@tanstack/react-router";
import { ContactPanel, PageHero, SiteFrame } from "@/components/site";
import { PAGE_META } from "@/lib/content";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: PAGE_META["/contact"].title },
      { name: "description", content: PAGE_META["/contact"].description },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <SiteFrame>
      <PageHero
        label="CONTACT"
        title="Start a conversation with Emilo Labs."
        summary="For partnerships, research, product, media, careers, or general inquiries, contact the institution directly."
      />
      <ContactPanel />
    </SiteFrame>
  );
}
