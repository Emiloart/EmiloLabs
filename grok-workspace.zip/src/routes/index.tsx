import { createFileRoute } from "@tanstack/react-router";
import { ContactBand, HomeHero, HomeProducts, PathGrid, SiteFrame } from "@/components/site";
import { PAGE_META } from "@/lib/content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: PAGE_META["/"].title },
      { name: "description", content: PAGE_META["/"].description },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <SiteFrame>
      <HomeHero />
      <PathGrid />
      <HomeProducts />
      <ContactBand />
    </SiteFrame>
  );
}
