import { createFileRoute } from "@tanstack/react-router";
import { InsightGrid, PageHero, SiteFrame } from "@/components/site";
import { PAGE_META } from "@/lib/content";

export const Route = createFileRoute("/insights")({
  head: () => ({
    meta: [
      { title: PAGE_META["/insights"].title },
      { name: "description", content: PAGE_META["/insights"].description },
    ],
  }),
  component: InsightsPage,
});

function InsightsPage() {
  return (
    <SiteFrame>
      <PageHero
        label="INSIGHTS"
        title="One editorial hub for the institution's thinking and work."
        summary="Articles, research briefs, field notes, documentaries, announcements, and other published material share one coherent publishing surface."
      />
      <section className="section">
        <div className="container">
          <InsightGrid />
        </div>
      </section>
    </SiteFrame>
  );
}
