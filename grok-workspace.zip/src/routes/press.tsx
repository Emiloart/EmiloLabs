import { createFileRoute } from "@tanstack/react-router";
import { PageHero, PressResources, SiteFrame } from "@/components/site";
import { PAGE_META } from "@/lib/content";

export const Route = createFileRoute("/press")({
  head: () => ({
    meta: [
      { title: PAGE_META["/press"].title },
      { name: "description", content: PAGE_META["/press"].description },
    ],
  }),
  component: PressPage,
});

function PressPage() {
  return (
    <SiteFrame>
      <PageHero
        label="PRESS"
        title="Official information for media and institutional inquiries."
        summary="A concise source for company context, media contact, and official information about Emilo Labs."
      />
      <PressResources />
    </SiteFrame>
  );
}
