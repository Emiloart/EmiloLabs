import { createFileRoute } from "@tanstack/react-router";
import { PageHero, ProductOperatingModel, Products, SiteFrame } from "@/components/site";
import { PAGE_META } from "@/lib/content";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: PAGE_META["/products"].title },
      { name: "description", content: PAGE_META["/products"].description },
    ],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  return (
    <SiteFrame>
      <PageHero
        label="PRODUCTS"
        title="Systems built for people, organizations, and connected digital environments."
        summary="The portfolio is presented in two states: Active and Coming Soon. That distinction keeps current products separate from systems still being prepared."
      />
      <ProductOperatingModel />
      <Products />
    </SiteFrame>
  );
}
