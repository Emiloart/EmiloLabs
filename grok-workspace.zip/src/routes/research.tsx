import { createFileRoute } from "@tanstack/react-router";
import { PageHero, PillarCards, ResearchTrackGrid, SiteFrame } from "@/components/site";
import { PAGE_META } from "@/lib/content";

export const Route = createFileRoute("/research")({
  head: () => ({
    meta: [
      { title: PAGE_META["/research"].title },
      { name: "description", content: PAGE_META["/research"].description },
    ],
  }),
  component: ResearchPage,
});

function ResearchPage() {
  return (
    <SiteFrame>
      <PageHero
        label="RESEARCH"
        title="Questions worth solving before systems are scaled."
        summary="Research at Emilo Labs spans identity, privacy, security, intelligent systems, financial systems, and internet infrastructure."
      />
      <ResearchTrackGrid />
      <PillarCards />
    </SiteFrame>
  );
}
