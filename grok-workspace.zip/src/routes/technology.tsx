import { createFileRoute } from "@tanstack/react-router";
import { CredibilityBand, PageHero, SiteFrame, Technology } from "@/components/site";
import { PAGE_META } from "@/lib/content";

export const Route = createFileRoute("/technology")({
  head: () => ({
    meta: [
      { title: PAGE_META["/technology"].title },
      { name: "description", content: PAGE_META["/technology"].description },
    ],
  }),
  component: TechnologyPage,
});

function TechnologyPage() {
  return (
    <SiteFrame>
      <PageHero
        label="TECHNOLOGY"
        title="The engineering foundations behind the work."
        summary="Software systems, identity and privacy infrastructure, security engineering, intelligent systems, financial technology, and exploratory domains."
      />
      <Technology />
      <CredibilityBand />
    </SiteFrame>
  );
}
